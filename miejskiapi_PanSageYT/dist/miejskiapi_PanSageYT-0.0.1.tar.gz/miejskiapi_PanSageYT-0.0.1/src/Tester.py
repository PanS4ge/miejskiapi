import MiejskiDefinicja, Sprawdzacz

print(Sprawdzacz.sprawdz("Apteka"))